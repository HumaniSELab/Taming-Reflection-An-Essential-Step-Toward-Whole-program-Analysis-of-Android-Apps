package lu.uni.snt.reflection9;

public class ConcreteClass {

	public String imei;
	
	public String getImei()
	{
		return imei;
	}
}
