/** Automatically generated file. DO NOT MODIFY */
package lu.uni.snt.reflection11;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}