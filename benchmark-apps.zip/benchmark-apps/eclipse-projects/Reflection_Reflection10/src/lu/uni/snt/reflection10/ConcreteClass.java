package lu.uni.snt.reflection10;

public class ConcreteClass 
{

	public String imei;
	
	public ConcreteClass(String imei)
	{
		this.imei = imei;
	}
	
	public String getImei()
	{
		return imei;
	}
}
