/** Automatically generated file. DO NOT MODIFY */
package lu.uni.snt.reflection12;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}