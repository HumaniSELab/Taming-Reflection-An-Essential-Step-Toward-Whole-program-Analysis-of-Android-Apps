/** Automatically generated file. DO NOT MODIFY */
package lu.uni.snt.reflection7;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}