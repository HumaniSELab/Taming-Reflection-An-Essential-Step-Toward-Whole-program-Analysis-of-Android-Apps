package lu.uni.snt.reflection8;

public class ConcreteClass extends BaseClass {

	public String foo() {
		return imei;
	}
	
}
