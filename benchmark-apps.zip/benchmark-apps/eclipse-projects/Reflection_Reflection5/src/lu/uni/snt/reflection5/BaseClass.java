package lu.uni.snt.reflection5;

public abstract class BaseClass {
	
	public String imei;
}
