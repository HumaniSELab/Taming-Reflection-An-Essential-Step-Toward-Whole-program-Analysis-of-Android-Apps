package lu.uni.snt.reflection13;

public abstract class BaseClass {
	
	public String imei;
}
