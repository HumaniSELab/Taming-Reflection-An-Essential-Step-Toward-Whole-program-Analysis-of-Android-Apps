package lu.uni.snt.reflection7;

public abstract class BaseClass {
	
	public String imei;
}
