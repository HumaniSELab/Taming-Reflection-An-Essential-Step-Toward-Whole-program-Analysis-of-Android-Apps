package lu.uni.snt.reflection8;

public abstract class BaseClass {
	
	public String imei;

	public abstract String foo();
}
