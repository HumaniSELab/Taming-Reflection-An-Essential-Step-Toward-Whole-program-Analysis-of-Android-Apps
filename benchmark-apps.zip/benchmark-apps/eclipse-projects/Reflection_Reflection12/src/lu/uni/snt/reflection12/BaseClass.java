package lu.uni.snt.reflection12;

public abstract class BaseClass {
	
	public String imei;
}
